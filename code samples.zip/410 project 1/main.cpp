/*
 * main.cpp
 *
 *  Created on: Jan 26, 2018
 *      Author: guest-v8uagn
 */
#include "utilities.h"
#include <iostream>
#include <string>
using namespace std;

int main(){
	const char* filename = "first";
	const char* secound = "secound";
	 std :: cout<<loadData(filename)<<endl;
	 sortData(START_TIME);
	 std :: cout<<saveData(secound)<<endl;
	//cout << b <<endl;
	return 0;
}



