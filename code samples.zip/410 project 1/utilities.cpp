/*
 * utilities.cpp
 *
 *  Created on: Jan 26, 2018
 *      Author: Samuel Allison
 */

#include "utilities.h"
#include <vector>
#include <iostream>
#include <fstream>
#include <sstream>
#include <algorithm>
using namespace std;

std :: vector<process_stats> myVector;

//sorts vectors by process_number
bool sortbyfirst(const process_stats a, const process_stats b){
	return (a.process_number < b.process_number);
}

//sorts vectors by start_time
bool sortbysec(const process_stats a, const process_stats b){
	return (a.start_time < b.start_time);
}

//sorts vectors by cpu_time
bool sortbythird(const process_stats a, const process_stats b){
	return (a.cpu_time < b.cpu_time);
}

//clears vector holding process_stats structs
//attempt to open file 'filename' to read, parse its rows
//into process_stats structs and add these structs to a vector
//
//returns SUCCESS if all goes well or COULD_NOT_OPEN_FILE
int loadData(const char* filename){
	myVector.clear();
	ifstream myfile;
	myfile.open(filename);
	//ifstream myfile(filename);

	string line;
	//stringstream ss;
	process_stats a;

	if(myfile.is_open()){
		while(getline(myfile,line)){
			stringstream ss(line);
			int d;
			int count = 0;
			while(ss >> d){
				if(ss.peek() == ',' || ss.peek() == ' '){
					ss.ignore();
				}
				if(count == 0){
					a.process_number = d;
					count ++;
				}
				else if(count == 1){
					a.start_time = d;
					count ++;
				}
				else if(count == 2){
					a.cpu_time = d;
					count ++;
				}
				else{
					count = 0;
				}

			}
			myVector.push_back(a);
		}
		myfile.close();
		return SUCCESS;
	}
	myfile.close();

	return COULD_NOT_OPEN_FILE;
}

//attempt to open file 'filename' to write, and serialize a
//vector full of process_stats structs to it.  Should be in the same
//format as original file but not necessarily the same order or length
//if the file exists, overwrite its contents.
//returns SUCCESS if all goes well or COULD_NOT_OPEN_FILE
int saveData(const char* filename){
	ofstream myfile;
	myfile.open(filename);
	if(myfile.is_open()){
		while(!myVector.empty()){
			process_stats a;
			a = getNext();
			myfile<< a.process_number;
			myfile<< ",";
			myfile<< a.start_time;
			myfile<< ",";
			myfile<< a.cpu_time;
			myfile<< "\n";
		}
		myfile.close();
		return SUCCESS;
	}
	myfile.close();
	return COULD_NOT_OPEN_FILE;
}
//sorts the vector, returns nothing (thats what void means)
//sorts low to high
void sortData(SORT_ORDER mySortOrder){
	switch(mySortOrder){
		case CPU_TIME:
			sort(myVector.begin(),myVector.end(),sortbythird);
			break;
		case PROCESS_NUMBER:
			std :: sort(myVector.begin(),myVector.end(),sortbyfirst);
			break;

		case START_TIME:
			std :: sort(myVector.begin(),myVector.end(),sortbysec);
			break;
	}
		//std :: sort(myVector.begin(),myVector.end());
}
//return the first struct in the vector
//then deletes it from the vector
process_stats getNext(){
	process_stats a;
	if(!myVector.empty()){
		a = myVector.front();
		myVector.erase(myVector.begin());
		return a;
	}
	return a;
}


