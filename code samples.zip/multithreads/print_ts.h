/*
 * print_ts.h
 *
 *  Created on: Mar 22, 2018
 *      Author: guest-i6ng3h
 */
#pragma once
#include <string>

void PRINT1(std::string &txt);
void PRINT2(std::string &txt, std::string &txt1);
void PRINT3(std::string &txt, std::string &txt1, std::string &txt2);
void PRINT4(std::string &txt, std::string &txt1, std::string &txt2, std::string &txt3);
void PRINT5(std::string &txt, std::string &txt1, std::string &txt2, std::string &txt3, std::string &txt4);
