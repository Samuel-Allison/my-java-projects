/*
 * main.cpp
 *
 *  Created on: Mar 22, 2018
 *      Author: guest-i6ng3h
 */
#include "tester.h"
#include <iostream>
int main(){
	int a = 0;
	startThreads("a",2,P1,4,9);
	startThreads("b",3,P2,5,9);
	startThreads("Hi ",3,P5,10,5);
	startThreads("stop ",2,P3,6,8);
	startThreads("help ",10,P4,9,8);

	/*for(int i = 0; i < 200; i++){
		a++;
	}
	if(a == 200){

		setCancelThreads(true);
	}*/
	joinThreads();
	return 0;
}




