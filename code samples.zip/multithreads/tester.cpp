
#include "tester.h"
#include "print_ts.h"
#include <iostream>
#include <vector>
#include <thread>
#include <string>
using namespace std;

std::vector<std::thread> thds;
int numTimes = 0;
bool bCanceled = false;

void callPrint1(std::string s,int numTimesToPrint, int millisecond_delay){
	for(int i = 0; i < numTimesToPrint; i++){
		if(bCanceled == true){
			string end = USER_CHOSE_TO_CANCEL;
			PRINT1(end);
			break;
		}
		else{
			PRINT1(s);
			std::this_thread::sleep_for(std::chrono::milliseconds(millisecond_delay));
		}
	}
}
void callPrint2(std::string s,int numTimesToPrint, int millisecond_delay){
	for(int i = 0; i < numTimesToPrint; i++){
		if(bCanceled == true){
			string end = USER_CHOSE_TO_CANCEL;
			PRINT1(end);
			break;
		}
		else{
			PRINT2(s,s);
			std::this_thread::sleep_for(std::chrono::milliseconds(millisecond_delay));
		}
	}
}
void callPrint3(std::string s,int numTimesToPrint, int millisecond_delay){
	for(int i = 0; i < numTimesToPrint; i++){
		if(bCanceled == true){
			string end = USER_CHOSE_TO_CANCEL;
			PRINT1(end);
			break;
		}
		else{
			PRINT3(s,s,s);
			std::this_thread::sleep_for(std::chrono::milliseconds(millisecond_delay));
		}
	}
}
void callPrint4(std::string s,int numTimesToPrint, int millisecond_delay){
	for(int i = 0; i < numTimesToPrint; i++){
		if(bCanceled == true){
			string end = USER_CHOSE_TO_CANCEL;
			PRINT1(end);
			break;
		}
		else{
			PRINT4(s,s,s,s);
			std::this_thread::sleep_for(std::chrono::milliseconds(millisecond_delay));
		}
	}
}
void callPrint5(std::string s,int numTimesToPrint, int millisecond_delay){
	for(int i = 0; i < numTimesToPrint; i++){
		if(bCanceled == true){
			string end = USER_CHOSE_TO_CANCEL;
			PRINT1(end);
			break;
		}
		else{
			PRINT5(s,s,s,s,s);
			std::this_thread::sleep_for(std::chrono::milliseconds(millisecond_delay));
		}
	}
}
/*
 * starts cancelable threads
 * string s			-the string to print
 * numThreads 		-the number of threads to start
 * wp 				-which print statement should be used
 * numTimesToPrint 	-the number of PRINT statements each thread will call
 * millisecond_delay- how long (in milliseconds) to wait between prints
 */
void startThreads(std::string s, int numThreads, WHICH_PRINT wp, int numTimesToPrint, int millisecond_delay){


				switch(wp){
						case P1:for(int i = 0; i < numThreads; i++){
							thds.push_back(std::thread(callPrint1,s,numTimesToPrint,millisecond_delay));
						}
						break;
						case P2:for(int i = 0; i < numThreads; i++){
							thds.push_back(std::thread(callPrint2,s,numTimesToPrint,millisecond_delay));
						}

						break;
						case P3:for(int i = 0; i < numThreads; i++){
							thds.push_back(std::thread(callPrint3,s,numTimesToPrint,millisecond_delay));
						}
						break;
						case P4:for(int i = 0; i < numThreads; i++){
							thds.push_back(std::thread(callPrint4,s,numTimesToPrint,millisecond_delay));
						}
						break;
						case P5:for(int i = 0; i < numThreads; i++){
							thds.push_back(std::thread(callPrint5,s,numTimesToPrint,millisecond_delay));
						}
						break;
						}



}

/*
 * if bCanceled== true then causes all running threads to print USER_CHOSE_TO_CANCEL and then exit
 * if false then just reset logic used to cancel threads
 */
void setCancelThreads(bool bCancel){
	if(bCancel == true){
		 bCanceled = true;
		//joinThreads();
	}
	else{
		bCanceled = false;
	}

}




/*
 * waits for all threads to complete
 */
void joinThreads(){

	for(auto& thread : thds){
		thread.join();
	}
}

