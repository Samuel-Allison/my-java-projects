#pragma once
#include "Smalltalk_American.h"
class ST_American_DonutEnthusiest :
	public Smalltalk_American
{
public:
	ST_American_DonutEnthusiest(int iPerson =1);
	virtual ~ST_American_DonutEnthusiest(void);
	virtual void populatePhrases();
};

