/*
 * ST_American_DonutEnthusiest.cpp
 *
 *  Created on: Nov 19, 2017
 *      Author: Samuel Allison
 */
#include "./includes/ST_American_DonutEnthusiest.h"
#include "./includes/constants.h"

ST_American_DonutEnthusiest :: ST_American_DonutEnthusiest(int iPerson):Smalltalk_American(AMERICAN_DE,iPerson){
	if(mySmallTalk.size() == 0){
		populatePhrases();
	}
}
ST_American_DonutEnthusiest :: ~ST_American_DonutEnthusiest(void){
	if(pWatch){
		delete pWatch;
		pWatch = NULL;
	}
}
void ST_American_DonutEnthusiest :: populatePhrases(){
	mySmallTalk.push_back(AMERICAN_DE_PHRASE_1);
	mySmallTalk.push_back(AMERICAN_DE_PHRASE_2);
	mySmallTalk.push_back(AMERICAN_DE_PHRASE_3);
	mySmallTalk.push_back(AMERICAN_DE_PHRASE_4);
	mySmallTalk.push_back(AMERICAN_DE_PHRASE_5);
}

