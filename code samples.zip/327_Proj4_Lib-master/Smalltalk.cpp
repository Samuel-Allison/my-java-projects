/*
 * Smalltalk.cpp
 *
 *  Created on: Nov 19, 2017
 *      Author: Samuel Allison
 */
#include <iostream>
#include "./includes/constants.h"
#include "./includes/Smalltalk.h"
#include "./includes/Watch.h"
#include <string>
#include <vector>

	//derived class will set Nationality, iPerson. iPerson is just a counter used to distinguish objects of the same type
Smalltalk :: Smalltalk(std::string myNationality,int iPerson):nationality(myNationality),iPerson(iPerson){
	this->iPerson ++;
	pWatch = 0;
	current_phrase = 0;
}
Smalltalk :: ~Smalltalk(void){
	if(pWatch){
		delete pWatch;
		pWatch = NULL;
	}
}

//cycles through and returns phrases created in populatePhrases
//takes the form Nationality iPerson: phrase
//for instance the following string comes from an American instance, the 10th iPerson and it is printing AMERICAN_PHRASE_2
//AMERICAN 10:Why yes, I would like to supersize that
std::string Smalltalk :: saySomething(){
	current_phrase = rand() % mySmallTalk.size() + 0;
	std :: string returned = "";
	returned += nationality ;
	returned += " ";
	returned += std::to_string(iPerson);
	returned += ":";
	returned += mySmallTalk[current_phrase];

	//current_phrase = current_phrase % mySmallTalk.size();
	return returned;
}

//returns the time or I_DO_NOT_HAVE_A_WATCH string
std::string Smalltalk :: getTime(){
	if(pWatch == 0){
		std :: string noTime = "";
		noTime += nationality;
		noTime += " ";
		noTime += std::to_string(iPerson);
		noTime += ":";
		noTime += I_DO_NOT_HAVE_A_WATCH;
		return noTime;
	}
	else{
		std :: string currTime = "";
		currTime += nationality;
		currTime += " ";
		currTime += std::to_string(iPerson);
		currTime += ":";
		currTime += pWatch->getTime();
		return currTime;
	}
}

//if this object has a watch it is taken away,
//this means return the pointer and set this->pWatch =NULL;
Watch* Smalltalk :: takeWatch(){
	if(this->pWatch == 0){
		return pWatch;
	}
	else{
		delete pWatch;
		return this->pWatch = NULL;
	}
}

//if already have a watch then return false and dont change pWatch pointer
//otherwise accept watch (return true) and set this->pWatch=pWatch
bool Smalltalk :: giveWatch(Watch *pWatch){
	if(this->pWatch == 0){
		this->pWatch = pWatch;
		return true;
	}
	return false;
}




