from operator import itemgetter, attrgetter


def process(after, input):
    a = len(input)
    numCrew = 0

    for n in input:
        for z in n:
            numCrew = numCrew + 1

    numCrew = numCrew - len(input)
    numCrew = numCrew / 2
    numCrew = int(numCrew)

    yourPick = numCrew - after
    yourPick = yourPick - 1
    yourPick = int(yourPick)

    numberOfPicks = 0

    yourSecoundPick = numCrew + after
    yourSecoundPick = int(yourSecoundPick)


    nameGem = []

    if yourPick == yourSecoundPick:
        yourSecoundPick = yourSecoundPick + 1

    secoundList = []
    for n in input:
        secoundList.append(n)

    thirdList = []

    for m in secoundList:
        for p in m:
            thirdList.append(p)

    switchAt = 0
    gemloc = 0
    for p in thirdList:
        if (isinstance(p, str)):
            gemloc = gemloc + 1


    for o in thirdList:
        if isinstance(o,str):
            nameGem.append(o)
            thirdList.remove(o)

    for x in thirdList:
        switchAt = switchAt + 1


    count = 0
    internalCount = 0
    thirdCount = 0

    if len(thirdList) == len(input):
        switchAt = len(thirdList) - 1
    else:
        switchAt = switchAt / gemloc

    listOfTuple = []
    while count <= len(thirdList):
        if switchAt == thirdCount:
            internalCount = internalCount + 1
            thirdCount = 0

        if count < len(thirdList):
            listOfTuple.append([nameGem[internalCount],thirdList[count]])
        count = count + 1
        thirdCount = thirdCount + 1
    yourlist = []
    maxValue = 0
    listOfTuple = sorted(listOfTuple, key=itemgetter(1, 0))
    popCount = -1
    found = 0
    while numberOfPicks < len(thirdList):
        for e in listOfTuple:
            popCount = popCount + 1
            if maxValue == 0:
                maxValue = e
            if e[1] > maxValue[1]:
                maxValue = e
                found = popCount


        if yourPick == numberOfPicks:
            yourlist.append(listOfTuple.pop(found))
        elif yourSecoundPick == numberOfPicks:
            yourlist.append((listOfTuple.pop(found)))
        else:
           valueRandom = listOfTuple.pop(found)

        maxValue = 0
        numberOfPicks = numberOfPicks + 1
        found = 0
        popCount = -1



    value1 = yourlist[0].pop()
    gem1 = yourlist[0].pop()
    value2 = yourlist[1].pop()
    gem2 = yourlist[1].pop()
    returnedString = gem1 + ":" + str(value1) + " " + gem2 + ":" + str(value2)
    return returnedString

def foo():

    x = 3

    def bar() :
        x = 9

        def jinx():
            print(x)

        def blah():
            x = 42
            jinx()

        def puff(x):
            jinx()
        jinx()
        blah()
        puff(15)
    bar()

foo()
