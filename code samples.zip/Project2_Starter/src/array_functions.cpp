/*
 * functionstocomplete.cpp
 *
 *  Created on: Oct 6, 2017
 *      Author: sam Allison
 */

#define ARRAY_FUNCTIONS_H_
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <algorithm>
#include "constants.h"
#include "array_functions.h"
#include "utilities.h"
using namespace std;
using namespace constants;

struct entry
{
	string word;
	int number_occurences;
};

bool isOpen = false;
int arraySize = 0;

entry myStruct [MAX_WORDS];



//zero out array that tracks words and their occurrences
void clearArray(){
	for(int i  = 0; i <= arraySize; i++){
		myStruct[i].word = "";
		myStruct[i].number_occurences = 0;
	}
	arraySize = 0;
}

//how many unique words are in array
int getArraySize(){
	return arraySize;
}

//get data at a particular location
std::string getArrayWordAt(int i){
	return myStruct[i].word;
}

//get data at a particular location
int getArrayWord_NumbOccur_At(int i){
	return myStruct[i].number_occurences;
}

/*Keep track of how many times each token seen*/
void processToken(std::string &token){

	strip_unwanted_chars(token);
	bool isin = false;
	string temp;
	string upperTemp;
	string temptoken = token;
	toUpper(temptoken);
	for(int i = 0; i <= getArraySize(); i++){
		temp = getArrayWordAt(i);
		upperTemp = getArrayWordAt(i);
		toUpper(upperTemp);
		if(upperTemp == temptoken){
			myStruct[i].number_occurences  = myStruct[i].number_occurences + 1;
			isin = true;
			break;
		}
	}
	if(isin == false){
		for(int j = 0; j <= getArraySize(); j++){
			if(getArrayWordAt(j) == ""){
				myStruct[j].word = token;
				myStruct[j].number_occurences = 1;
				arraySize ++;
				break;
			}
		}
	}
}


/*take 1 line and extract all the tokens from it
feed each token to processToken for recording*/

void processLine(std::string &myString){

	stringstream ss(myString);string tempToken;
	while (getline(ss, tempToken, CHAR_TO_SEARCH_FOR)) {
		processToken(tempToken);
	}
}

/*loop through whole file, one line at a time
 * call processLine on each line
 * returns false: myfstream is not open
 *         true: otherwise*/

bool processFile(std::fstream &myfstream){
	if(myfstream.is_open() == true){
		string line;
		while(!myfstream.eof()){
			getline(myfstream,line);
			processLine(line);
		}
		myfstream.close();
		return true;
	}

	return false;
}

/*if you are debugging the file must be in the project parent directory
  in this case Project2 with the .project and .cProject files*/

bool openFile(std::fstream& myfile, const std::string& myFileName,
		std::ios_base::openmode mode = std::ios_base::in){

		myfile.open(myFileName.c_str(),mode);
		if(myfile.is_open() == true){
			isOpen = true;
			return true;
		}
		return false;
}

/*iff myfile is open then close it*/

void closeFile(std::fstream& myfile){
	if(myfile.is_open() == true){
		myfile.close();
		isOpen = false;
	}
}

/* serializes all content in myEntryArray to file outputfilename
 * returns  FAIL_FILE_DID_NOT_OPEN if cannot open outputfilename
 * 			FAIL_NO_ARRAY_DATA if there are 0 entries in myEntryArray
 * 			SUCCESS if all data is written and outputfilename closes OK
 **/

int writeArraytoFile(const std::string &outputfilename){
	if(getArraySize() == 0){
		return FAIL_NO_ARRAY_DATA;
	}

	if(outputfilename == ""){
		return FAIL_FILE_DID_NOT_OPEN;
	}

	fstream myOutPutFile;
	myOutPutFile.open(outputfilename.c_str());


	string myoutput;
	for(int i = 0; i < getArraySize(); i++){
		//cout<<myStruct[i].word + " " + intToString(myStruct[i].number_occurences)<<endl;
		myoutput = myStruct[i].word + " " + intToString(myStruct[i].number_occurences) ;
		myOutPutFile << myoutput<<endl;
	}
	closeFile(myOutPutFile);
	return SUCCESS;


}
/*

 * Sort myEntryArray based on so enum value.
 * You must provide a solution that handles alphabetic sorting (A-Z)
 * The presence of the enum implies a switch statement based on its value
 * You are provided with a myentry compare function in the cpp file
*/

void sortArray(constants::sortOrder so){
	string first;
	string secound;
	switch(so){
	case(0):
			break;

	case(1):

				for(int i = 0; i < arraySize; i ++){
					for(int j =0; j < arraySize; j++){
						first = myStruct[i].word;
						secound = myStruct[j].word;
						toUpper(first);
						toUpper(secound);
						if(first > secound || first == secound){

						}
						else{
							entry temp = myStruct[i];
							myStruct[i] = myStruct[j];
							myStruct[j] = temp;
						}
					}
				}
	break;
	case(2):
			for(int i = 0; i < arraySize; i ++){
				for(int j =0; j < arraySize; j++){
					first = myStruct[i].word;
					secound = myStruct[j].word;
					toUpper(first);
					toUpper(secound);
					if(first < secound || first == secound){

					}
					else{
						entry temp = myStruct[i];
						myStruct[i] = myStruct[j];
						myStruct[j] = temp;
					}
				}
			}
	break;
	case(3):
			for(int i = 0; i < arraySize; i ++){
				for(int j =0; j < arraySize; j++){
					if(myStruct[i].number_occurences > myStruct[j].number_occurences || myStruct[i].number_occurences == myStruct[j].number_occurences){

					}
					else{
						entry temp = myStruct[i];
						myStruct[i] = myStruct[j];
						myStruct[j] = temp;
					}
				}
			}
	break;
	}
}




