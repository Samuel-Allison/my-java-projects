import numpy as np
from rotations import *
import HW2_6 as hw


m = np.array([[1.0, 0.0, 0.0],
                [0.0, 1.0, 0.0],
                  [0.0, 0.0, 1.0]])

n = np.array([[1.0, 0.0],
                  [0.0, 1.0]])

print("question 1")
def quest1():
    alpha = 2.0
    beta = 0.0
    theta = 0.0
    Rx = rotX(alpha)
    Ry = rotY(beta)
    Rz = rotZ(theta)
    a = transform2D(2.0, 0.0, Rz)
    print(a)
    print()

    theta = np.radians(45)
    Rz = rotZ(theta)
    b = transform2D(0.0, 0.0, Rz)
    print(b)
    print()

    theta = 0.0
    Rz = rotZ(theta)
    c = transform2D(0.5, 0.0, Rz)
    print(c)
    print()

    theta = np.radians(-30)
    Rz = rotZ(theta)
    d = transform2D(0.0, 0.0, Rz)
    print(d)
    print()

    theta = 0.0
    Rz = rotZ(theta)
    e = transform2D(0.25, 0.0, Rz)
    print(e)
    print()
    total = np.dot(np.dot(np.dot(a,b), np.dot(c,d)),e)
    print(total)
    print('End question 1')
    print()


def quest2():
    print('question 2')

    theta = np.pi/6.0
    Rz = rotZ(theta)
    car = transform2D(3.5, -.25, Rz)
    print(car)
    print()

    theta = np.pi/10.0
    Rz = rotZ(theta)
    lidar = transform2D(0.1, 0.0, Rz)
    print(lidar)

    theta = 0.0
    Rz = rotZ(theta)
    tree = transform2D(0.5, 0.0, n)
    print(tree)

    objects = np.dot(np.dot(car, lidar), tree)
    print(objects)
    print('end question 2')
    print()


def quest3():
    print('start question 3')
    print()

    Rz = rotZ(0.0)
    print('a)')
    print('matrix')
    print(Rz)
    print('quaternion')
    print(M2Q(Rz))

    print(makeEss(np.pi / 2.0, np.pi / 2.0, np.pi / 2.0, 'b', 'c', 'd'))
    print(makeEss(np.pi / 3.0, np.pi / 3.0, np.pi / 3.0, 'e', 'f', 'g'))
    print(makeEss(np.pi / 4.0, np.pi / 4.0, np.pi / 4.0, 'h', 'i', 'j'))
    print(makeEss(np.pi / 6.0, np.pi / 6.0, np.pi / 6.0, 'k', 'l', 'm'))
    print(makeEss(np.pi / -3.0, np.pi / -3.0, np.pi / -3.0, 'n', 'o', 'p'))
    print(makeEss(np.pi / -6.0, np.pi / -6.0, np.pi / -6.0, 'q', 'r', 's'))

    print('end question 3')
    print()


def makeEss(first, second, third, letterA, letterB, letterC):
    Rx = rotX(first)
    Ry = rotY(second)
    Rz = rotZ(third)
    print(letterA + ')')
    print('matrix')
    print(Rx)
    print('quaternion')
    print(M2Q(Rx))

    print(letterB + ')')
    print('matrix')
    print(Ry)
    print('quaternion')
    print(M2Q(Ry))

    print(letterC + ')')
    print('matrix')
    print(Rz)
    print('quaternion')
    print(M2Q(Rz))


def quest4():

    print('Start question 4')
    print()
    mat = np.array([[0.7474, 0.5430, 0.3826, .2528],
                [-0.2936, 0.7867, -0.5430, -0.8787],
                [-0.5960, 0.2936, 0.7474, -0.4321],
                [0, 0, 0, 1]])
    print(M2Q(mat))
    print('end question 4')
    print()


def quest5():
    print('start question 5')
    quatly = np.array([0.74846, 0.13062, .50764, 0.40626])
    print(Q2M(quatly))
    print('end question 5')
    print()


def quest6():
    print('Start question 6')
    print('part a)')
    print("pTw * wTu * uTr_arm * r_armTr_arm * r_armTr_arm * r_armTr_arm_e *"
      " r_arm_eTr_arm_w * r_arm_wTr_arm_w * r_arm_wTr_hand * r_handTr_palm")

    print('b)')
    loco = Q1xQ2(hw.q_pel_wst, hw.q_wst_tor)
    loco2 = Q1xQ2(loco, hw.q_tor_shp)
    loco3 = Q1xQ2(loco2, hw.q_shp_shr)
    loco4 = Q1xQ2(loco3, hw.q_shr_shy)
    loco5 = Q1xQ2(loco4, hw.q_shy_el)
    loco6 = Q1xQ2(loco5, hw.q_el_wy)
    loco7 = Q1xQ2(loco6, hw.q_wy_wr)
    loco8 = Q1xQ2(loco7, hw.q_wr_hnd)
    loco9 = Q1xQ2(loco8, hw.q_hnd_plm)
    print(loco9)
    print()
    print(Q2M(loco9))
    print()
    print("c)")
    print("I got nothing here")
    print('end question 6')
    print()


def quest7():
    print('Start question 7')
    print('part a)')
    x = np.sin(np.pi/8.0) * .25
    y = np.cos(np.pi/8.0) * .25
    print("X", x)
    print("Y", y)
    print()

    print('part b)')
    r = .25 * 10
    c = .258 / 2
    rL = c + r
    rR = r - c
    tanspeedL = rL * .1
    tanspeedR = rR * .1

    radios = .0645 / 2
    RwL = tanspeedL / radios
    RwR = tanspeedR / radios
    print("Left wheel",RwL)
    print("right wheel",RwR)
quest1()
quest2()
quest3()
quest4()
quest5()
quest6()
quest7()
